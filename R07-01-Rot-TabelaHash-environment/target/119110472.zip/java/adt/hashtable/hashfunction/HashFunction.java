package adt.hashtable.hashfunction;

/**
 * It represents a generic hash function that will be used by a hashtable to
 * calculate indexes in the internal array.
 */
public interface HashFunction<T> {

}
